Xw = fft(x);
f = [-(N/2):1:(N/2)-1]*(1/N);
w = 2*pi*f;
Zw =Xw.*Xw;
disp(Zw);