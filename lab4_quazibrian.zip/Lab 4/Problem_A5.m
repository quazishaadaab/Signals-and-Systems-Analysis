%Pulse width 10
N=100;
PulseWidth = 10;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
Xf = fft(x);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(Xf)));
grid on;
title ('Figure 7');
xlabel('\omega');
ylabel('|Z(\omega)|');
subplot(2,1,2);
plot(f,fftshift(angle(Xf)));
grid on;
title ('Figure 8');
xlabel('\omega');
ylabel('\angle Z(\omega)');

%Pulse width 5
N=100;
PulseWidth = 5;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
Xf = fft(x);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(Xf)));
grid on;
title ('Figure 9');
xlabel('\omega');
ylabel('|Z(\omega)|');
subplot(2,1,2);
plot(f,fftshift(angle(Xf)));
grid on;
title ('Figure 10');
xlabel('\omega');
ylabel('\angle Z(\omega)');

%Pulse Width 25
N=100;
PulseWidth = 25;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
Xf = fft(x);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(Xf)));
grid on;
title ('Figure 11');
xlabel('\omega');
ylabel('|Z(\omega)|');
subplot(2,1,2);
plot(f,fftshift(angle(Xf)));
grid on;
title ('Figure 12');
xlabel('\omega');
ylabel('\angle Z(\omega)');

