close all ;

%the signal
figure ; 
MagSpect(xspeech);
title('xspeech');xlabel('frequency in Hz');ylabel('Magnitude in db');
%put xspeech through 1st low pass filter to get sample size
figure ;
Sample=conv(xspeech,hLPF2000);
MagSpect(Sample);
title('1st low pass filter');

%modulate the signal so it can fit in the hchannel 
figure;
Mod=osc(3000,length(Sample),32000);
Signal=Sample.*Mod;
MagSpect(Signal);
title('modulated signal');

%send that signal through hchannel
figure;
Output=conv(Signal,hChannel);
MagSpect(Output);
title('hchannel');

%Demodulate the signal so it can be at its first state
figure;
Demodulation=osc(3000,length(Output),32000);
Demodulate=Output.*Demodulation;
MagSpect(Demodulate);
title('demodulated signal');

%Put throught the second low pass filter 
figure;
Final=conv(Demodulate,hLPF2500);
MagSpect(Final);
title('end signal');
%hear the sound
sound(Final,32000);
