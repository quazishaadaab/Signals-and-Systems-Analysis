%w+(t)
N=100;
PulseWidth = 10;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
wt = x.*(exp(1i*(pi/3).*t));
wtw = fft(wt);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(wtw)));
grid on;
title ('Figure 13');
xlabel('t');
ylabel('|w+(t)|');
subplot(2,1,2);
plot(f,fftshift(angle(wtw)));
grid on;
title ('Figure 14');
xlabel('t');
ylabel('\angle w+(t)');

%w-(t)
N=100;
PulseWidth = 10;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
wt = x.*(exp(1i*(pi/3).*t));
wtw = fft(wt);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(wtw)));
grid on;
title ('Figure 15');
xlabel('t');
ylabel('|w-(t)|');
subplot(2,1,2);
plot(f,fftshift(angle(wtw)));
grid on;
title ('Figure 16');
xlabel('t');
ylabel('\angle w-(t)');

%wc(t)
N=100;
PulseWidth = 10;
t = [0:1:(N-1)];
x = [ones(1,PulseWidth), zeros(1,N-PulseWidth)];
wt = x.*cos((pi/3).*t);
wtw = fft(wt);
f = [-(N/2):1:(N/2)-1]*(1/N);
figure;
subplot(2,1,1);
plot(f,fftshift(abs(wtw)));
grid on;
title ('Figure 17');
xlabel('t');
ylabel('|wc(t)|');
subplot(2,1,2);
plot(f,fftshift(angle(wtw)));
grid on;
title ('Figure 18');
xlabel('t');
ylabel('\angle wc(t)');

